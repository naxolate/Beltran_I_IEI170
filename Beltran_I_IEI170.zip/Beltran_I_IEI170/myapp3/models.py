from django.db import models

""" class Empleados(models.Model):
    id = models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=50)
    email = models.EmailField()
    sueldo = models.DecimalField(max_digits=6, decimal_places=2)
 """
""" class Proyecto(models.Model):
    FechaInicio = models.DateField()
    FechaTermino = models.DateField()
    nombre = models.CharField(max_length=50)
    responsable = models.CharField(max_length=50)
    prioridad = models.IntegerField()


   # pip install mysqlcliente  """

# Create your models here.
class Reservas(models.Model):
    id = models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=80)
    telefono = models.IntegerField()
    fr = models.DateField()#fecha de reserva
    hora = models.TimeField()
    cantidad = models.IntegerField()
    correo = models.EmailField()
    estado = models.CharField(max_length=80, null=True, blank=True)
    observacion = models.CharField(max_length=130)

    #def setArray(self, array_data):
        #self.estado = json.dumps(array_data)

    #def getArray(self):
        #return json.loads(self.estado)  