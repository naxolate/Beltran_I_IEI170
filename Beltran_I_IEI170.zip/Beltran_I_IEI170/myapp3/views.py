from django.shortcuts import render , redirect

from .models import Reservas
from . import forms
# Create your views here.
def index(request):
    return render(request, 'index.html')


def listaReserva(request):
    rese = Reservas.objects.all()##basicamente hacer un SELECT * FROM RESERVAS
    data = {'res': rese}
    return render(request,'reservas.html', data)

def eliminarReserva(request, id):
    re = Reservas.objects.get(id = id)
    re.delete()
    return redirect('/reservas')

def modificarReservas(request, id):
    re = Reservas.objects.get(id = id)
    form = forms.FormReservas()
    if (request.method == 'POST'):
        form = forms.FormReservas(request.POST, instance=re)
        if (form.is_valid()):
            form.save()
    data = {'form': form}
    return render(request, 'agregar.html', data) ###

""" def agregarReservas(request):
    form = forms.FormReservas()
    data = {'formss' : form}
    return render(request, 'registro.html', data) """

def agregarReservas(request):
    form = forms.FormReservas()
    if (request.method == 'POST'):
        form = forms.FormReservas(request.POST)
        if (form.is_valid()):
            form.save()
    data = {'form': form}
    return render(request, 'agregar.html', data)




""" def example_view(request):
    obj = Reservas()
    obj.setArray(['RESERVADO', 'COMPLETADA', 'ANULADA', 'NO ASISTEN'])
    obj.save()

    array1 = obj.getArray()
    print(array1)  

    # Other view logic
    return render(request, 'reservas.html', {'data': array1}) """



""" def listaproyecto(request):
    proye = Reservas.objects.all()## hacer un SELECT * FROM reservas
    data = {'pro': proye}
    return render(request,'proyecto.html', data)
 """
