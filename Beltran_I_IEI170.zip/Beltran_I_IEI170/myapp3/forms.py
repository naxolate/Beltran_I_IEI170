from django import forms
from django.core import validators
from . import models

class FormReservas(forms.ModelForm):
        class Meta:
            model = models.Reservas
            fields = '__all__'    
        ESTADOS  = (
            ('Seleccione estado', 
                (('reservado', 'RESERVADO'),
                ('completada', 'COMPLETADA'),
                ('anulada', 'ANULADA'),
                ('no asisten', 'NO ASISTEN'))
            ),)
            #[('seleccionar', 'SELECCIONAR'), ('reservado', 'RESERVADO'), ('completada', 'COMPLETADA'), ('anulada', 'ANULADA'), ('no asisten', 'NO ASISTEN')]

        nombre = forms.CharField(validators=[validators.MinLengthValidator(3), validators.MaxLengthValidator(20)])
        telefono = forms.IntegerField()
        fr = forms.DateField()#fecha de reserva                                                                                                                                                                                                                                                                                                                                                                                     
        hora = forms.TimeField()
        cantidad = forms.IntegerField(validators=[validators.MaxValueValidator(15),validators.MinValueValidator(1)])
        correo = forms.EmailField(widget=forms.EmailInput)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      
        estado = forms.CharField(widget=forms.Select(choices=ESTADOS))
        observacion = forms.CharField() #require=False


 # """   class Meta:
  #      model = models.Reservas
   #     fields ='__all__'
 #"""